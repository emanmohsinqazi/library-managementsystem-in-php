<?php
session_start();

function request_book($book_name, $author_id) {
    // Adjust the database connection details
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $student_id = $_SESSION['id'];
    $status = 0; // 0: Pending request
    $request_date = date("Y-m-d");

    $query = "INSERT INTO requests (student_id, book_name, author_id, status, request_date) VALUES ($student_id, '$book_name', $author_id, $status, '$request_date')";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        // Notify the user that the request has been submitted
        $notification_message = "Your book request for '$book_name' has been submitted.";
        $notification_query = "INSERT INTO notifications (student_id, message, date) VALUES ($student_id, '$notification_message', '$request_date')";
        mysqli_query($connection, $notification_query);

        return true;
    } else {
        return false;
    }
}

if (isset($_POST['request_book'])) {
    $book_name = $_POST['book_name'];
    $author_id = $_POST['book_author'];

    if (request_book($book_name, $author_id)) {
        header("Location: user_dashboard.php?success=request");
        exit();
    } else {
        echo "Error submitting the book request.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Book Request</title>
    <!-- Add your CSS and JS dependencies here -->
</head>

<body>
    <!-- Your existing HTML code for the book request form -->
</body>

</html>
