<?php
require("functions.php");
session_start();

// Check if there's a success or error message in the URL
$successMessage = isset($_GET['success']) ? $_GET['success'] : '';
$errorMessage = isset($_GET['error']) ? $_GET['error'] : '';

// Logic to process book request actions
if (isset($_GET['request_id']) && isset($_GET['action'])) {
    $request_id = $_GET['request_id'];
    $action = $_GET['action'];

    if ($action === 'accept') {
        // Implement the logic to accept the book request
        if (accept_book_request($request_id)) {
            // Redirect back to view_book_requests.php with success message
            header("Location: view_book_requests.php?success=accept");
            exit();
        } else {
            // Redirect back to view_book_requests.php with error message
            header("Location: view_book_requests.php?error=accept");
            exit();
        }
    } elseif ($action === 'reject') {
        // Implement the logic to reject the book request
        if (reject_book_request($request_id)) {
            // Redirect back to view_book_requests.php with success message
            header("Location: view_book_requests.php?success=reject");
            exit();
        } else {
            // Redirect back to view_book_requests.php with error message
            header("Location: view_book_requests.php?error=reject");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Book Requests</title>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap-4.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="../bootstrap-4.4.1/js/jquery_latest.js"></script>
    <script type="text/javascript" src="../bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container mt-4">
        <h2>Book Requests</h2>

        <?php
        // Display success message if available
        if ($successMessage) {
            echo '<div class="alert alert-success" role="alert">' . $successMessage . '</div>';
        }

        // Display error message if available
        if ($errorMessage) {
            echo '<div class="alert alert-danger" role="alert">' . $errorMessage . '</div>';
        }
        ?>

        <table class="table">
            <thead>
                <tr>
                    <th>Request ID</th>
                    <th>Student ID</th>
                    <th>Book Name</th>
                    <th>Author ID</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $book_requests = get_book_requests();
                foreach ($book_requests as $request) {
                    echo "<tr>";
                    echo "<td>" . (isset($request['id']) ? $request['id'] : "") . "</td>";
                    echo "<td>" . (isset($request['student_id']) ? $request['student_id'] : "") . "</td>";
                    echo "<td>" . (isset($request['book_name']) ? $request['book_name'] : "") . "</td>";
                    echo "<td>" . (isset($request['author_id']) ? $request['author_id'] : "") . "</td>";
                    echo '<td><a href="process_request.php?request_id=' . (isset($request['id']) ? $request['id'] : "") . '&action=accept" class="btn btn-success">Accept</a> ';
                    echo '<a href="process_request.php?request_id=' . (isset($request['id']) ? $request['id'] : "") . '&action=reject" class="btn btn-danger">Reject</a></td>';
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
