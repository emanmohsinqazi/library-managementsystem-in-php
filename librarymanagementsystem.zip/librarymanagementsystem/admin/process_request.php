<?php
require("functions.php");
session_start();

if (isset($_GET['request_id']) && isset($_GET['action'])) {
    $request_id = $_GET['request_id'];
    $action = $_GET['action'];

    // Debugging statements
    echo "Request ID: $request_id, Action: $action";

    $request = get_book_request_by_id($request_id);

    if ($action === 'accept' && isset($request['id'])) {
        // Debugging statement
        echo "Accepting request";

        // Implement the logic to accept the book request
        if (accept_book_request($request_id)) {
            // Debugging statement
            echo "Request accepted successfully";

            // Redirect back to view_book_requests.php with success message
            header("Location: view_book_requests.php?success=accept");
            exit();
        } else {
            // Debugging statement
            echo "Error accepting request";

            // Redirect back to view_book_requests.php with error message
            header("Location: view_book_requests.php?error=accept");
            exit();
        }
    } elseif ($action === 'reject' && isset($request['id'])) {
        // Debugging statement
        echo "Rejecting request";

        // Implement the logic to reject the book request
        if (reject_book_request($request_id)) {
            // Debugging statement
            echo "Request rejected successfully";

            // Redirect back to view_book_requests.php with success message
            header("Location: view_book_requests.php?success=reject");
            exit();
        } else {
            // Debugging statement
            echo "Error rejecting request";

            // Redirect back to view_book_requests.php with error message
            header("Location: view_book_requests.php?error=reject");
            exit();
        }
    }
}

// Redirect to the admin_dashboard.php if no valid parameters are provided
header("Location: admin_dashboard.php");
exit();
?>
