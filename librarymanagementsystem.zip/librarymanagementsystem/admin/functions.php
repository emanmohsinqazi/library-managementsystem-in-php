<?php
	function get_author_count(){
		$connection = mysqli_connect("localhost:3307","root","");
		$db = mysqli_select_db($connection,"librarymanagementsystem");
		$author_count = 0;
		$query = "select count(*) as author_count from authors";
		$query_run = mysqli_query($connection,$query);
		while ($row = mysqli_fetch_assoc($query_run)){
			$author_count = $row['author_count'];
		}
		return($author_count);
	}
	// functions.php
	



function decrement_pending_requests() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    // Fetch the current number of pending requests
    $current_pending_requests = get_pending_requests_count();

    // If there are pending requests, decrement the count
    if ($current_pending_requests > 0) {
        $new_pending_requests = $current_pending_requests - 1;

        // Update the pending requests count
        $update_query = "UPDATE site_settings SET pending_requests = $new_pending_requests WHERE id = 1";
        $update_result = mysqli_query($connection, $update_query);

        if (!$update_result) {
            die("Error updating pending requests count: " . mysqli_error($connection));
        }
    }
}

function get_pending_requests_count() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $query = "SELECT pending_requests FROM site_settings WHERE id = 1";
    $query_run = mysqli_query($connection, $query);

    if (!$query_run) {
        die("Error in query: " . mysqli_error($connection));
    }

    $row = mysqli_fetch_assoc($query_run);
    return $row['pending_requests'];
}

	
	
	
	// functions.php



function get_total_requests() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $query = "SELECT total_requests FROM site_settings WHERE id = 1";
    $query_run = mysqli_query($connection, $query);

    if (!$query_run) {
        die("Error in query: " . mysqli_error($connection));
    }

    $row = mysqli_fetch_assoc($query_run);
    return $row['total_requests'];
}

	// functions.php
	
	
function get_book_requests() {
    // Implement the logic to fetch book requests from the database
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $book_requests = [];

    $query = "SELECT * FROM requests WHERE status = 0 ORDER BY request_date DESC";

    $query_run = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($query_run)) {
        $book_requests[] = $row;
    }

    return $book_requests;
}
// functions.php

function get_book_request_by_id($request_id) {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    // Check if $request_id is empty or not a number
    if (empty($request_id) || !is_numeric($request_id)) {
        return false; // Or handle the error appropriately
    }

    // Use prepared statement to avoid SQL injection
    $query = "SELECT * FROM requests WHERE id = ?";
    
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $request_id);
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        die("Error in query: " . mysqli_error($connection));
    }

    return mysqli_fetch_assoc($result);
}

	
	function get_user_count(){
		$connection = mysqli_connect("localhost:3307","root","");
		$db = mysqli_select_db($connection,"librarymanagementsystem");
		$user_count = 0;
		$query = "select count(*) as user_count from users";
		$query_run = mysqli_query($connection,$query);
		while ($row = mysqli_fetch_assoc($query_run)){
			$user_count = $row['user_count'];
		}
		return($user_count);
	}

	function get_book_count(){
		$connection = mysqli_connect("localhost:3307","root","");
		$db = mysqli_select_db($connection,"librarymanagementsystem");
		$book_count = 0;
		$query = "select count(*) as book_count from books";
		$query_run = mysqli_query($connection,$query);
		while ($row = mysqli_fetch_assoc($query_run)){
			$book_count = $row['book_count'];
		}
		return($book_count);
	}

	function get_issue_book_count(){
		$connection = mysqli_connect("localhost:3307","root","");
		$db = mysqli_select_db($connection,"librarymanagementsystem");
		$issue_book_count = 0;
		$query = "select count(*) as issue_book_count from issued_books";
		$query_run = mysqli_query($connection,$query);
		while ($row = mysqli_fetch_assoc($query_run)){
			$issue_book_count = $row['issue_book_count'];
		}
		return($issue_book_count);
	}

	function get_category_count(){
		$connection = mysqli_connect("localhost:3307","root","");
		$db = mysqli_select_db($connection,"librarymanagementsystem");
		$cat_count = 0;
		$query = "select count(*) as cat_count from category";
		$query_run = mysqli_query($connection,$query);
		while ($row = mysqli_fetch_assoc($query_run)){
			$cat_count = $row['cat_count'];
		}
		return($cat_count);
	}
	// functions.php

function accept_book_request($request_id) {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    // Get request details
    $request = get_book_request_by_id($request_id);

    // Update request status
    $query = "UPDATE requests SET status = 1 WHERE id = $request_id";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        // Send notification to the user
        $user_id = $request['student_id'];
        $message = "Your book request for '{$request['book_name']}' has been accepted.";
        send_notification($user_id, $message);

        // Remove the request
        remove_book_request($request_id);

        // Decrement pending requests count
        decrement_pending_requests();

        // Do not increment the issued_books count for accepted requests
    }

    return $query_run;
}

function reject_book_request($request_id) {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    // Get request details
    $request = get_book_request_by_id($request_id);

    // Update request status
    $query = "UPDATE requests SET status = 2 WHERE id = $request_id";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        // Send notification to the user
        $user_id = $request['student_id'];
        $message = "Your book request for '{$request['book_name']}' has been rejected.";
        send_notification($user_id, $message);

        // Remove the request
        remove_book_request($request_id);

        // Decrement pending requests count
        decrement_pending_requests();

        // Do not increment the issued_books count for rejected requests
    }

    return $query_run;
}


function send_notification($user_id, $message) {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    // Insert notification into the notifications table
    $insert_query = "INSERT INTO notifications (user_id, message) VALUES ($user_id, '$message')";
    $insert_result = mysqli_query($connection, $insert_query);

    if (!$insert_result) {
        die("Error inserting notification: " . mysqli_error($connection));
    }
}

function remove_book_request($request_id) {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    // Remove the request from the requests table
    $delete_query = "DELETE FROM requests WHERE id = $request_id";
    $delete_result = mysqli_query($connection, $delete_query);

    if (!$delete_result) {
        die("Error deleting request: " . mysqli_error($connection));
    }
}

?>