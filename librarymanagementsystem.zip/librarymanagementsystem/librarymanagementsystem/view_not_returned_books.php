<?php
session_start();

function get_not_returned_books() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $not_returned_books = array();

    // Assuming 'status' column indicates the book status (1: issued, 0: returned)
    $query = "SELECT * FROM issued_books WHERE student_id = $_SESSION[id] AND status = 1";

    $query_run = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($query_run)) {
        $not_returned_books[] = $row;
    }

    return $not_returned_books;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Not Returned Books</title>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-4.4.1/js/jquery_latest.js"></script>
    <script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <h2>Not Returned Books</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Book No</th>
                    <th>Book Name</th>
                    <th>Author</th>
                    <th>Issue Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $not_returned_books = get_not_returned_books();
                foreach ($not_returned_books as $book) {
                    echo "<tr>";
                    echo "<td>" . $book['book_no'] . "</td>";
                    echo "<td>" . $book['book_name'] . "</td>";
                    echo "<td>" . $book['book_author'] . "</td>";
                    echo "<td>" . $book['issue_date'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>
