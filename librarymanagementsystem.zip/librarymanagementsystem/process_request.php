<?php
   session_start();

   if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $book_title = $_POST["book_title"];
      $student_id = $_SESSION["id"];

      $connection = mysqli_connect("localhost:3307", "root", "");
      $db = mysqli_select_db($connection, "librarymanagementsystem");

      $query = "INSERT INTO demanded_books (student_id, book_title) VALUES ('$student_id', '$book_title')";
      $result = mysqli_query($connection, $query);

      if ($result) {
         echo "<script>alert('Book requested successfully!');</script>";
      } else {
         echo "<script>alert('Error requesting book. Please try again.');</script>";
      }
   }
?>
