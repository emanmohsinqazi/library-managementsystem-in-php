<?php
session_start();

function get_notifications() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $notifications = [];

    $query = "SELECT * FROM notifications WHERE user_id = $_SESSION[id] ORDER BY timestamp DESC";

    $query_run = mysqli_query($connection, $query);

    if (!$query_run) {
        die("Error in query: " . mysqli_error($connection));
    }

    while ($row = mysqli_fetch_assoc($query_run)) {
        $notifications[] = $row;
    }

    return $notifications;
}


function request_book_notification($book_name) {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $user_id = $_SESSION['id'];
    $notification_message = "You have requested the book '$book_name'.";
    $notification_date = date("Y-m-d H:i:s");

    $insert_query = "INSERT INTO notifications (user_id, message, timestamp) VALUES ($user_id, '$notification_message', '$notification_date')";
    $query_run = mysqli_query($connection, $insert_query);

    if (!$query_run) {
        die("Error in query: " . mysqli_error($connection));
    }
}

// Handle form submission for book request
if (isset($_POST['request_book'])) {
    $book_name = $_POST['book_name'];
    $author_id = $_POST['book_author'];

    // Process the book request
    if (request_book($book_name, $author_id)) {
        // Notify the user that the request has been submitted
        request_book_notification($book_name);

        // Set success status message
        $status_message = "Book request submitted successfully. You will be notified once it is processed.";
        header("Location: user_dashboard.php?success=request");
        exit();
    } else {
        // Set error status message
        $status_message = "Error submitting the book request.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Notifications</title>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-4.4.1/js/jquery_latest.js"></script>
    <script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <!-- Add your navbar content here -->
        </div>
    </nav><br>

    <div class="container mt-4">
        <h2>Notifications</h2>

        <table class="table">
            <thead>
                <tr>
                    <th>Message</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $notifications = get_notifications();
                foreach ($notifications as $notification) {
                    echo "<tr>";
                    echo "<td>" . $notification['message'] . "</td>";
                    echo "<td>" . $notification['timestamp'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>
