<?php
session_start();

function get_user_issue_book_count() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");
    $user_issue_book_count = 0;

    // Assuming 'status' column indicates the book status (1: issued, 0: returned)
    $query = "SELECT COUNT(*) AS user_issue_book_count FROM issued_books WHERE student_id = $_SESSION[id] AND status = 1";

    $query_run = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($query_run)) {
        $user_issue_book_count = $row['user_issue_book_count'];
    }

    return $user_issue_book_count;
}

function get_not_returned_book_count() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");
    $not_returned_book_count = 0;

    // Assuming 'status' column indicates the book status (1: issued, 0: returned)
    $query = "SELECT COUNT(*) AS not_returned_book_count FROM issued_books WHERE student_id = $_SESSION[id] AND status = 1";

    $query_run = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($query_run)) {
        $not_returned_book_count = $row['not_returned_book_count'];
    }

    return $not_returned_book_count;
}

function get_notifications() {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $notifications = [];

    // Assuming 'date' column exists in your notifications table
    $query = "SELECT * FROM notifications WHERE user_id = $_SESSION[id] ORDER BY timestamp DESC";


    $query_run = mysqli_query($connection, $query);

    if (!$query_run) {
        die("Error in query: " . mysqli_error($connection));
    }

    while ($row = mysqli_fetch_assoc($query_run)) {
        $notifications[] = $row;
    }

    return $notifications;
}


// Function to handle book requests
function request_book($book_name, $author_id) {
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    $student_id = $_SESSION['id'];
    $status = 0; // 0: Pending request
    $request_date = date("Y-m-d");

    $query = "INSERT INTO requests (student_id, book_name, author_id, status, request_date) VALUES ($student_id, '$book_name', $author_id, $status, '$request_date')";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        // Notify the user that the request has been submitted
        request_book_notification($book_name); 
        $notification_message = "Your book request for '$book_name' has been submitted.";
        $notification_date = date("Y-m-d H:i:s");
        $notification_query = "INSERT INTO notifications (user_id, message, timestamp) VALUES ($student_id, '$notification_message', '$notification_date')";
        mysqli_query($connection, $notification_query);

        // Store the request details in the database
        $request_details_query = "INSERT INTO requests (request_id,student_id, book_name, author_id, request_date, status) VALUES ($student_id, '$book_name', $author_id, '$request_date', $status)";
        mysqli_query($connection, $request_details_query);

        return true;
    } else {
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Dashboard</title>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-4.4.1/js/jquery_latest.js"></script>
    <script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="admin_dashboard.php">Library Management System (LMS)</a>
            </div>
            <font style="color: white"><span><strong>Welcome: <?php echo $_SESSION['name']; ?></strong></span></font>
            <font style="color: white"><span><strong>Email: <?php echo $_SESSION['email']; ?></strong></font>
            <ul class="nav navbar-nav navbar-right">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">My Profile</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="view_profile.php">View Profile</a>
                        <a class="dropdown-item" href="edit_profile.php">Edit Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="change_password.php">Change Password</a>
                    </div>
                </li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="row" style="width: 100%">
        <div class="col-md-2 bg-light">
            <br><br>
            <ul class="nav nav-pills nav-stacked">
                <li class="nav-item"><a class="nav-link" href="user_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="view_books.php">View Books</a></li>
                <li class="nav-item"><a class="nav-link" href="view_issued_book.php">View Issued Books</a></li>
                <li class="nav-item"><a class="nav-link" href="view_notifications.php">View Notifications</a></li>
            </ul>
        </div>

        <div class="col-md-10">
            <h2>Welcome <?php echo $_SESSION['name']; ?></h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card bg-light" style="width: 300px; margin-top: 25px;">
                        <div class="card-header">Book Issued</div>
                        <div class="card-body">
                            <p class="card-text">No of books issued: <?php echo get_user_issue_book_count(); ?></p>
                            <a class="btn btn-success" href="view_issued_book.php">View Issued Books</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card bg-light" style="width: 300px; margin-top: 25px;">
                        <div class="card-header">Book Request</div>
                        <div class="card-body">
                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="book_name">Book Name:</label>
                                    <input type="text" name="book_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="book_author">Author ID:</label>
                                    <input type="text" name="book_author" class="form-control" required>
                                </div>
                                <button type="submit" name="request_book" class="btn btn-primary">Request Book</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card bg-light" style="width: 300px; margin-top: 25px;">
                        <div class="card-header">Notifications</div>
                        <div class="card-body">
                            <?php
                            $notifications = get_notifications();
                            if (empty($notifications)) {
                                echo '<p class="card-text">No new notifications</p>';
                            } else {
                                foreach ($notifications as $notification) {
                                    echo '<p class="card-text">' . $notification['message'] . ' - ' . $notification['date'] . '</p>';
                                }
                            }
                            ?>
                            <a class="btn btn-info" href="view_notifications.php">View All Notifications</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
