<?php
session_start();
if (isset($_GET['request_id']) && isset($_GET['action'])) {
    $request_id = $_GET['request_id'];
    $action = $_GET['action'];

    if ($action === 'accept') {
        // Implement the logic to accept the book request
        if (accept_book_request($request_id)) {
            // Redirect back to view_book_requests.php with success message
            header("Location: view_book_requests.php?success=accept");
            exit();
        } else {
            // Redirect back to view_book_requests.php with error message
            header("Location: view_book_requests.php?error=accept");
            exit();
        }
    } elseif ($action === 'reject') {
        // Implement the logic to reject the book request
        if (reject_book_request($request_id)) {
            // Redirect back to view_book_requests.php with success message
            header("Location: view_book_requests.php?success=reject");
            exit();
        } else {
            // Redirect back to view_book_requests.php with error message
            header("Location: view_book_requests.php?error=reject");
            exit();
        }
    }
}

// Redirect to the admin_dashboard.php if no valid parameters are provided
header("Location: admin_dashboard.php");
exit();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish database connection
    $connection = mysqli_connect("localhost:3307", "root", "");
    $db = mysqli_select_db($connection, "librarymanagementsystem");

    // Check if the connection is successful
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get the book title from the form
    $bookTitle = $_POST['bookTitle'];

    // Assuming you have a 'demanded_books' table
    $query = "INSERT INTO demanded_books (student_id, book_title) VALUES ('$_SESSION[id]', '$bookTitle')";

    $result = mysqli_query($connection, $query);

    // Check if the query was successful
    if ($result) {
        echo "Book demand submitted successfully.";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($connection);
    }

    // Close the database connection
    mysqli_close($connection);
}
?>
