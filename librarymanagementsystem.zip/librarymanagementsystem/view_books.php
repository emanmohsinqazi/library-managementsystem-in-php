<?php
session_start(); // Assuming you are using sessions on your site

// Replace the following with your actual database connection logic
$connection = mysqli_connect("localhost:3307", "root", "", "librarymanagementsystem");

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch the list of books from the database
$query = "SELECT * FROM books";
$query_run = mysqli_query($connection, $query);

$books = [];

// Check if there are books in the database
if (mysqli_num_rows($query_run) > 0) {
    while ($row = mysqli_fetch_assoc($query_run)) {
        $books[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>View Books</title>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-4.4.1/js/jquery_latest.js"></script>
    <script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <!-- Your navigation bar content goes here -->
        </div>
    </nav><br>

    <div class="container mt-4">
        <h2>View Books</h2>

        <?php if (empty($books)) : ?>
            <div class="alert alert-warning" role="alert">
                No books found in the database.
            </div>
        <?php else : ?>
            <!-- Display the list of books in a table -->
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                        <!-- Add more columns as needed -->
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($books as $book) : ?>
                        <tr>
                            <td><?php echo $book['book_id']; ?></td>
                            <td><?php echo $book['book_name']; ?></td>
                            <td><?php echo $book['author_id']; ?></td>
                            <!-- Add more cells with book details as needed -->
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>

</html>
